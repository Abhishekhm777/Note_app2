package com.souvik.noteapplication;

import android.content.SharedPreferences;
import android.util.Log;

import com.souvik.noteapplication.Model.DataModel;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmAsyncTask;
import io.realm.RealmResults;

public class RealmHelper {
    Realm realm;
    RealmResults<DataModel> userDetails;
    Boolean saved,delete;


    public RealmHelper(Realm realm) {
        this.realm = realm;

    }
    public void delete(){
        realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        realm.deleteAll();

        realm.commitTransaction();

    }

    public void retrieveDB()
    {
        userDetails=realm.where(DataModel.class).findAll();
    }
    public Integer dbSize(){
        userDetails=realm.where(DataModel.class).findAll();
        return userDetails.size();
    }

    ///////////////////////////////////////////////write into DB/////////////////////////////////////////////////
    public void writeToDB( final String title,final Integer UserId,final int id,final Boolean complete) {
        try {


            realm.executeTransactionAsync(new Realm.Transaction() {
                @Override
                public void execute(Realm bgRealm) {

                    DataModel dm = bgRealm.createObject(DataModel.class, id);
                    dm.setTitle(title);
                    dm.setUserId(UserId);
                    dm.setCompleted(complete);
                    bgRealm.commitTransaction();


                }
            }, new Realm.Transaction.OnSuccess() {
                @Override
                public void onSuccess() {


                }
            }, new Realm.Transaction.OnError() {
                @Override
                public void onError(Throwable error) {

                    // Transaction failed and was automatically canceled.
                    Log.e("Database", error.getMessage());
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }



    //READ
    public ArrayList<DataModel> justreferesh()
    {
        ArrayList<DataModel> productsList=new ArrayList<>();


        for(DataModel dm:userDetails)
        {
            productsList.add(dm);

        }
        // return retrieve();
        return productsList;
    }

}
