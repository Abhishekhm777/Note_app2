package com.souvik.noteapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.souvik.noteapplication.Model.DataModel;
import com.souvik.noteapplication.Model.MainModel;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmResults;


public class DisplayFragment extends Fragment {

   private RecyclerView recyclerView;
   private DataAdapter dataAdapter;
   private MainModel mainViewModel;
    private Realm realm;
    private RealmHelper helper;
     static int count=0;
   public static TextView textView;
   private RealmResults<DataModel> getResult;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_display, container, false);
        textView=view.findViewById(R.id.count);
        recyclerView=(RecyclerView)view.findViewById(R.id.recyclerview) ;
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(),1,GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        realm= Realm.getDefaultInstance();
       // getResult = realm.where(DataModel.class).findAll();

        helper=new RealmHelper(realm);
        mainViewModel= ViewModelProviders.of(getActivity()).get(MainModel.class);
        mainViewModel.init();
        mainViewModel.getData().observe(getActivity(), new Observer<ArrayList<DataModel>>() {
            @Override
            public void onChanged(ArrayList<DataModel> dataModels) {
                if(dataModels!=null){

                    getResult = realm.where(DataModel.class).findAll();

                        dataAdapter = new DataAdapter(getActivity(), getResult, getFragmentManager());
                        recyclerView.setAdapter(dataAdapter);
                        countCheck();




                }

            }
        });



        return view;
    }

    private void countCheck(){

        RealmResults<DataModel> getRes = realm.where(DataModel.class).equalTo("completed", true).findAll();
        count=getRes.size();
        textView.setText("Fav Count:"+String.valueOf(count));
    }



    @Override
    public void onResume() {
        super.onResume();
        if(dataAdapter!=null) {
            dataAdapter.notifyDataSetChanged();
        }
    }
}


