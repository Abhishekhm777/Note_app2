package com.souvik.noteapplication;

public interface OnCountChangeListener {
    public void onCountChanged(int check);
}
