package com.souvik.noteapplication.Repository;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;

import com.souvik.noteapplication.Api_instance;
import com.souvik.noteapplication.DataAdapter;
import com.souvik.noteapplication.Model.DataModel;
import com.souvik.noteapplication.RealmHelper;
import com.souvik.noteapplication.UrlCall;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class NoteRepository {
    private static NoteRepository instance;
    private ArrayList<DataModel> dataModel;
    MutableLiveData<ArrayList<DataModel>> data;
    private Realm realm;
    private RealmHelper helper;


    public static NoteRepository getInstance(){
        if(instance==null){
            instance=new NoteRepository();

        }
        return instance;
    }
    public MutableLiveData<ArrayList<DataModel>> getUserDetails(){
        realm= Realm.getDefaultInstance();
        helper=new RealmHelper(realm);
        getUser();
        data = new MutableLiveData<>();
        data.setValue(dataModel);
        return data;
    }

    //////////////////////////////////user details////////////////////////////////
    public void getUser(){

        UrlCall retrofitCall= Api_instance.getUserDetails();
        Call<ArrayList<DataModel>> userInfo=retrofitCall.userInfo();
        userInfo.enqueue(new Callback<ArrayList<DataModel>>() {
            @Override
            public void onResponse(Call<ArrayList<DataModel>> call, Response<ArrayList<DataModel>> response) {
             if(response.isSuccessful()){
                 dataModel=response.body();

                 for(DataModel dataModels:dataModel){
                     realm.beginTransaction();
                     helper.writeToDB(dataModels.getTitle(),dataModels.getUserId(),dataModels.getId(),dataModels.getCompleted());
                     realm.commitTransaction();
                 }

                 data.postValue(dataModel);
             }
            }

            @Override
            public void onFailure(Call<ArrayList<DataModel>> call, Throwable t) {

            }
        });

    }

}
