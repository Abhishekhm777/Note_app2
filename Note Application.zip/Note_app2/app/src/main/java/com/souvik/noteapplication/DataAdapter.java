package com.souvik.noteapplication;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceControl;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.souvik.noteapplication.Model.DataModel;

import io.realm.RealmResults;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.MyViewHolder>{

private Context mContext;
//private ArrayList<DataModel> dataList;
  private   RealmResults<DataModel> dataList;
  FragmentManager fragmentManager;

public DataAdapter(Context mContext, RealmResults<DataModel> dataList, FragmentManager fragmentManager) {
        this.mContext = mContext;
        this.dataList = dataList;
        this.fragmentManager=fragmentManager;
        }

@NonNull
@Override
public DataAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout , parent, false);

        return new MyViewHolder(itemView);
        }

@Override
public void onBindViewHolder(@NonNull final DataAdapter.MyViewHolder holder, final int position) {
    holder.user_id.setText("UserId: "+String.valueOf(dataList.get(position).getId()));
    holder.title_text.setText(dataList.get(position).getTitle());
    if(dataList.get(position).getCompleted()==true){
        holder.checkBox.setChecked(true);
    }
    else {
        holder.checkBox.setChecked(false);
    }


    holder.checkBox.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CheckBox checkBox = (CheckBox)view;
            if(checkBox.isChecked()){
                DisplayFragment.count=DisplayFragment.count+1;
                DisplayFragment.textView.setText("Fav Count:"+String.valueOf(DisplayFragment.count));
            }
            else {
                DisplayFragment.count=DisplayFragment.count-1;
                DisplayFragment.textView.setText("Fav Count:"+String.valueOf(DisplayFragment.count));
            }
        }
    });


    holder.cardView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Bundle bundle=new Bundle();
            bundle.putInt("id",dataList.get(holder.getAdapterPosition()).getId());
            Fragment fragment_account = new Edit_fragment();
            fragment_account.setArguments(bundle);
          fragmentManager.beginTransaction().replace(R.id.change_layout, fragment_account).addToBackStack(null).commit();
        }
    });

}


    @Override
    public int getItemCount () {
        return dataList.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView user_id, title_text;
        CheckBox checkBox;
        CardView cardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            user_id = (TextView) itemView.findViewById(R.id.user_id);
            title_text = (TextView) itemView.findViewById(R.id.title);
            checkBox=(CheckBox)itemView.findViewById(R.id.checkBox);
            cardView=(CardView)itemView.findViewById(R.id.cardview);
        }

    }
}
